from django.db import models

class SiteConfiguration(models.Model):
    site_name = models.CharField(max_length=100)
    logo = models.ImageField(upload_to='logos/')
    
    def __str__(self):
        return self.site_name

class TeamMember(models.Model):
    name = models.CharField(max_length=100)
    bio = models.TextField()
    photo = models.ImageField(upload_to='team_photos/')
    def __str__(self):
        return self.name 

class SocialMediaLink(models.Model):
    SOCIAL_MEDIA_CHOICES = [
        ('instagram', 'Instagram'),
        ('facebook', 'Facebook'),
        ('twitter', 'Twitter'),
        ('telegram', 'Telegram'),
    ]

    platform = models.CharField(max_length=50, choices=SOCIAL_MEDIA_CHOICES)
    url = models.URLField()

    def __str__(self):
        return self.platform

class Contact(models.Model):
    email = models.EmailField()
    phone = models.CharField(max_length=20)

class Review(models.Model):
    name = models.CharField(max_length=100)
    bio = models.TextField()
    photo = models.ImageField(upload_to='review_photos/')
    def __str__(self):
        return self.name 
    

class Booking(models.Model):
    name=models.CharField(max_length=30)
    email=models.EmailField()
    phoneNumber=models.CharField(max_length=12)
    description=models.TextField()

    def __str__(self) : 
        return f'Message from {self.name}'
    
class Gallery(models.Model):
    photo = models.ImageField(upload_to='gallery_photos/')
   